#!/usr/bin/env python3
"""Seven LAN Bridge: dependency-free LAN text/file sharing with real-time SSE."""
from __future__ import annotations

import argparse
from collections import deque
from datetime import datetime, timezone
import hmac
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import queue
import re
import secrets
import socket
import threading
import time
from urllib.parse import parse_qs, quote, urlsplit
import uuid

HERE = Path(__file__).resolve().parent
MAX_MESSAGE = 8000
MAX_NOTE = 50000
MAX_JSON = 256 * 1024
KEEP_MESSAGES = 200
KEEP_FILES = 200
MAX_CLIENTS = 64


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def clean_name(value, fallback='访客', maximum=30):
    value = str(value or '')
    value = re.sub(r'[\x00-\x1f\x7f]', '', value).strip()
    return value[:maximum] or fallback


def client_id(value):
    return re.sub(r'[^a-zA-Z0-9_-]', '', str(value or ''))[:80] or uuid.uuid4().hex


def file_name(value):
    value = str(value or '').replace('\\', '/').split('/')[-1]
    value = re.sub(r'[\x00-\x1f\x7f]', '_', value).strip().strip('.')
    return value[:180] or 'unnamed-file'


def local_ipv4_addresses():
    """Best effort; server will also print the URLs when possible."""
    found = []
    def add(ip):
        if ip and ':' not in ip and not ip.startswith('127.') and ip != '0.0.0.0' and ip not in found:
            found.append(ip)
    for dest in ('192.0.2.1', '8.8.8.8'):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.connect((dest, 80))  # UDP connect only; sends no traffic
                add(sock.getsockname()[0])
        except OSError:
            pass
    try:
        for ai in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            add(ai[4][0])
    except OSError:
        pass
    return found


class ShareState:
    def __init__(self, data_dir, max_file_bytes, pin):
        self.lock = threading.RLock()
        self.data_dir = Path(data_dir).resolve()
        self.upload_dir = self.data_dir / 'uploads'
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.state_file = self.data_dir / 'state.json'
        self.max_file_bytes = max_file_bytes
        self.pin = pin
        self.sessions = {}  # random session token -> expiry (unix seconds)
        self.login_attempts = {}  # IP -> failure timestamps
        self.clients = {}  # connection uuid -> {cid,name,ip,queue}
        self.messages = deque(maxlen=KEEP_MESSAGES)
        self.files = deque(maxlen=KEEP_FILES)
        self.note = {'text': '', 'revision': 0, 'by': '', 'byId': '', 'updatedAt': None}
        self.ips = local_ipv4_addresses()
        if self.state_file.is_file():
            try:
                stored = json.loads(self.state_file.read_text(encoding='utf-8'))
                self.messages.extend(stored.get('messages', [])[-KEEP_MESSAGES:])
                self.files.extend(f for f in stored.get('files', [])[-KEEP_FILES:] if (self.upload_dir / f.get('id', '')).is_file())
                self.note.update(stored.get('note', {}))
                print(f'已恢复历史：{len(self.messages)} 条消息、{len(self.files)} 个文件')
            except (OSError, ValueError, TypeError) as exc:
                print(f'注意：历史状态读取失败，使用空白状态：{exc}')

    def persist(self):
        # Called while self.lock is held, serializing updates and writes.
        data = {'messages': list(self.messages), 'files': list(self.files), 'note': self.note}
        tmp = self.state_file.with_name('state.' + uuid.uuid4().hex + '.tmp')
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
            os.replace(tmp, self.state_file)
        finally:
            tmp.unlink(missing_ok=True)

    def peers(self):
        users = {}
        for item in self.clients.values():
            cid = item['cid']
            if cid not in users:
                users[cid] = {'id': cid, 'name': item['name'], 'ip': item['ip'], 'count': 0}
            users[cid]['count'] += 1
        return list(users.values())

    def snapshot(self):
        return {'messages': list(self.messages), 'files': list(self.files), 'note': self.note.copy(), 'peers': self.peers()}

    def publish(self, kind, obj):
        # Caller holds self.lock. Slow or disconnected peers never block writers.
        item = (kind, json.dumps(obj, ensure_ascii=False, separators=(',', ':')))
        for conn in self.clients.values():
            outgoing = conn['queue']
            try:
                outgoing.put_nowait(item)
            except queue.Full:
                try:
                    outgoing.get_nowait()
                    outgoing.put_nowait(('resync', '{}'))
                except queue.Empty:
                    pass

    def is_authorized(self, handler):
        if not self.pin:
            return True
        try:
            cookies = SimpleCookie()
            cookies.load(handler.headers.get('Cookie', ''))
            token = cookies['seven_lan_bridge_session'].value if 'seven_lan_bridge_session' in cookies else ''
        except Exception:
            return False
        with self.lock:
            return bool(token and self.sessions.get(token, 0) > time.time())


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'SevenLANBridge/1.1'

    @property
    def state(self):
        return self.server.share_state

    def log_message(self, fmt, *args):
        # Suppress repetitive EventSource/heartbeat logs; show mutating calls.
        if self.path.startswith('/api/events'):
            return
        print(f'[{self.log_date_time_string()}] {self.client_address[0]} {fmt % args}')

    def headers_common(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Cache-Control', 'no-store')

    def respond(self, status=200, payload=None, content_type='application/json; charset=utf-8', extra_headers=None):
        if payload is None:
            data = b''
        elif isinstance(payload, bytes):
            data = payload
        else:
            data = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.headers_common()
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != 'HEAD':
            try:
                self.wfile.write(data)
            except (ConnectionError, OSError):
                pass

    def fail(self, status, detail):
        self.respond(status, {'error': detail})

    def need_auth(self):
        if not self.state.is_authorized(self):
            self.fail(HTTPStatus.UNAUTHORIZED, '需要先输入访问码')
            return True
        return False

    def valid_origin(self):
        origin = self.headers.get('Origin')
        if not origin:
            return True  # Non-browser tools; password protects when enabled.
        try:
            parsed = urlsplit(origin)
            return parsed.netloc.lower() == self.headers.get('Host', '').lower() and parsed.scheme in ('http', 'https')
        except ValueError:
            return False

    def get_json(self):
        try:
            length = int(self.headers.get('Content-Length', '-1'))
        except ValueError:
            length = -1
        if length < 0 or length > MAX_JSON:
            self.close_connection = True
            self.fail(413, '请求内容过大或缺少 Content-Length')
            return None
        try:
            data = json.loads(self.rfile.read(length).decode('utf-8'))
            if not isinstance(data, dict):
                raise ValueError('需要 JSON 对象')
            return data
        except (ValueError, UnicodeDecodeError):
            self.fail(400, 'JSON 格式无效，请确认使用 UTF-8')
            return None

    def do_GET(self):
        parsed = urlsplit(self.path)
        path = parsed.path
        if path in ('/', '/index.html'):
            try:
                self.respond(200, (HERE / 'index.html').read_bytes(), 'text/html; charset=utf-8')
            except FileNotFoundError:
                self.fail(500, 'index.html 未找到，请放在 server.py 同一目录')
            return
        if path == '/favicon.ico':
            self.respond(204)
            return
        if path == '/api/hello':
            ip = self.client_address[0]
            host = self.headers.get('Host', '')
            request_ip = host.split(':')[0]
            candidates = self.state.ips[:]
            if re.fullmatch(r'\d{1,3}(?:\.\d{1,3}){3}', request_ip) and not request_ip.startswith('127.') and request_ip not in candidates:
                candidates.insert(0, request_ip)
            self.respond(200, {
                'viewerIp': ip,
                'serverIps': candidates,
                'serverUrls': [f'http://{address}:{self.server.server_port}' for address in candidates],
                'pinRequired': bool(self.state.pin),
                'authenticated': self.state.is_authorized(self),
                'maxFileBytes': self.state.max_file_bytes,
            })
            return
        if self.need_auth():
            return
        if path == '/api/events':
            self.stream_events(parsed.query)
            return
        if path.startswith('/api/download/'):
            self.download_file(path.removeprefix('/api/download/'))
            return
        self.fail(404, '找不到该资源')

    def do_POST(self):
        parsed = urlsplit(self.path)
        path = parsed.path
        if not self.valid_origin():
            self.close_connection = True
            self.fail(403, '跨站请求已拒绝')
            return
        if path == '/api/login':
            self.login()
            return
        if self.need_auth():
            self.close_connection = True
            return
        if path == '/api/messages':
            info = self.get_json()
            if info is None:
                return
            msg = str(info.get('text', '')).strip()
            if not msg or len(msg) > MAX_MESSAGE:
                self.fail(400, f'文本需要在 1–{MAX_MESSAGE} 字符之间')
                return
            item = {'id': uuid.uuid4().hex, 'clientId': client_id(info.get('clientId')),
                    'name': clean_name(info.get('name')), 'text': msg, 'createdAt': utcnow()}
            with self.state.lock:
                self.state.messages.append(item)
                self.state.persist()
                self.state.publish('message', item)
            self.respond(201, {'message': item})
            return
        if path == '/api/note':
            info = self.get_json()
            if info is None:
                return
            body = info.get('text', '')
            if not isinstance(body, str) or len(body) > MAX_NOTE:
                self.fail(400, f'便签长度不能超过 {MAX_NOTE} 字符')
                return
            with self.state.lock:
                if not info.get('force') and info.get('baseRevision') != self.state.note['revision']:
                    self.respond(409, {'error': '便签已被其他设备修改', 'note': self.state.note.copy()})
                    return
                self.state.note = {'text': body, 'revision': self.state.note['revision'] + 1,
                                   'by': clean_name(info.get('name')), 'byId': client_id(info.get('clientId')),
                                   'updatedAt': utcnow()}
                self.state.persist()
                self.state.publish('note', self.state.note.copy())
                result = self.state.note.copy()
            self.respond(200, {'note': result})
            return
        if path == '/api/upload':
            self.upload_file(parse_qs(parsed.query))
            return
        self.close_connection = True
        self.fail(404, '找不到该接口')

    def login(self):
        info = self.get_json()
        if info is None:
            return
        if not self.state.pin:
            self.respond(200, {'ok': True})
            return
        ip = self.client_address[0]
        now = time.time()
        with self.state.lock:
            recent = [t for t in self.state.login_attempts.get(ip, []) if now - t < 60]
            if len(recent) >= 8:
                self.fail(429, '尝试次数过多，请一分钟后再试')
                return
            if not hmac.compare_digest(str(info.get('pin', '')), self.state.pin):
                recent.append(now)
                self.state.login_attempts[ip] = recent
                self.fail(403, '访问码不正确')
                return
            self.state.login_attempts.pop(ip, None)
            token = secrets.token_urlsafe(32)
            self.state.sessions[token] = now + 7 * 24 * 3600
        self.respond(200, {'ok': True}, extra_headers={
            'Set-Cookie': f'seven_lan_bridge_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800'
        })

    def stream_events(self, query):
        q = parse_qs(query)
        cid = client_id(q.get('cid', [''])[0])
        name = clean_name(q.get('name', [''])[0])
        ip = self.client_address[0]
        conn_id = uuid.uuid4().hex
        outgoing = queue.Queue(maxsize=256)
        with self.state.lock:
            if len(self.state.clients) >= MAX_CLIENTS:
                self.fail(503, '连接设备太多')
                return
            self.state.clients[conn_id] = {'cid': cid, 'name': name, 'ip': ip, 'queue': outgoing}
            snapshot = self.state.snapshot()
            self.state.publish('presence', {'peers': snapshot['peers']})
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream; charset=utf-8')
            self.send_header('Cache-Control', 'no-store, no-transform')
            self.send_header('Connection', 'keep-alive')
            self.send_header('X-Accel-Buffering', 'no')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(b'retry: 1800\n\n')
            self.sse_event('snapshot', json.dumps(snapshot, ensure_ascii=False, separators=(',', ':')))
            while True:
                try:
                    event, payload = outgoing.get(timeout=15)
                    self.sse_event(event, payload)
                except queue.Empty:
                    self.wfile.write(b': heartbeat\n\n')
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, TimeoutError, OSError):
            pass
        finally:
            with self.state.lock:
                self.state.clients.pop(conn_id, None)
                self.state.publish('presence', {'peers': self.state.peers()})

    def sse_event(self, event, payload):
        self.wfile.write(f'event: {event}\ndata: {payload}\n\n'.encode('utf-8'))
        self.wfile.flush()

    def upload_file(self, q):
        try:
            size = int(self.headers.get('Content-Length', '-1'))
        except ValueError:
            size = -1
        if size < 0 or size > self.state.max_file_bytes:
            self.close_connection = True
            self.fail(413, f'文件超过 {self.state.max_file_bytes // (1024 * 1024)} MB 限制，或缺少文件长度')
            return
        filename = file_name(q.get('name', [''])[0])
        user_id = client_id(q.get('cid', [''])[0])
        name = clean_name(q.get('user', [''])[0])
        fid = uuid.uuid4().hex
        location = self.state.upload_dir / fid
        temp = self.state.upload_dir / (fid + '.part')
        try:
            remaining = size
            with temp.open('wb') as stream:
                while remaining:
                    block = self.rfile.read(min(256 * 1024, remaining))
                    if not block:
                        raise ConnectionError('文件上传中断')
                    stream.write(block)
                    remaining -= len(block)
            os.replace(temp, location)
        except (OSError, ConnectionError):
            temp.unlink(missing_ok=True)
            self.close_connection = True
            return
        item = {'id': fid, 'name': filename, 'size': size,
                'clientId': user_id, 'by': name, 'createdAt': utcnow()}
        with self.state.lock:
            self.state.files.appendleft(item)
            self.state.persist()
            self.state.publish('file', item)
        self.respond(201, {'file': item})

    def download_file(self, fid):
        if not re.fullmatch(r'[0-9a-f]{32}', fid):
            self.fail(404, '文件不存在')
            return
        with self.state.lock:
            entry = next((f for f in self.state.files if f['id'] == fid), None)
        if not entry:
            self.fail(404, '文件不存在')
            return
        target = self.state.upload_dir / fid
        try:
            file_size = target.stat().st_size
            stream = target.open('rb')
        except OSError:
            self.fail(404, '文件已被删除')
            return
        with stream:
            guessed = mimetypes.guess_type(entry['name'])[0] or 'application/octet-stream'
            ascii_name = re.sub(r'[^a-zA-Z0-9_.-]', '_', entry['name']) or 'download'
            disp = f'attachment; filename="{ascii_name}"; filename*=UTF-8\'\'{quote(entry["name"])}'
            self.send_response(200)
            self.send_header('Content-Type', guessed)
            self.send_header('Content-Disposition', disp)
            self.send_header('Content-Length', str(file_size))
            self.headers_common()
            self.end_headers()
            try:
                while True:
                    block = stream.read(256 * 1024)
                    if not block:
                        break
                    self.wfile.write(block)
            except (ConnectionError, OSError):
                pass


def main():
    parser = argparse.ArgumentParser(description='局域网实时文字 / 文件共享，无第三方依赖')
    parser.add_argument('--host', default='0.0.0.0', help='监听地址（默认 0.0.0.0）')
    parser.add_argument('--port', type=int, default=8000, help='监听端口（默认 8000）')
    parser.add_argument('--data', default=str(HERE / 'shared_data'), help='消息及上传文件存储目录')
    parser.add_argument('--max-file-mb', type=int, default=200, help='每个文件的最大 MB（默认 200）')
    parser.add_argument('--pin', default=os.environ.get('SEVEN_LAN_BRIDGE_PIN', os.environ.get('LAN_BRIDGE_PIN', '')), help='可选访问码，也可设置 SEVEN_LAN_BRIDGE_PIN 环境变量')
    args = parser.parse_args()
    if not 1 <= args.port <= 65535 or args.max_file_mb < 1:
        parser.error('端口和最大文件大小需要是合法正整数')
    state = ShareState(args.data, args.max_file_mb * 1024 * 1024, args.pin)
    class Server(ThreadingHTTPServer):
        daemon_threads = True
        allow_reuse_address = True
    try:
        with Server((args.host, args.port), Handler) as httpd:
            httpd.share_state = state
            print('\n  Seven LAN Bridge  ·  局域网共享空间')
            print('  Mac 本机： http://localhost:' + str(args.port))
            for ip in state.ips:
                print(f'  局域网：   http://{ip}:{args.port}')
            if not state.ips:
                print('  未检测到局域网地址；可使用 macOS「系统设置 → 网络」查看 IP')
            print('  访问保护：' + ('已启用 PIN' if args.pin else '未启用（同网络的设备均可访问）'))
            print('  数据目录：' + str(state.data_dir))
            print('  Ctrl+C 停止服务\n')
            httpd.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        print('\n服务已停止')
    except OSError as exc:
        parser.error(f'监听失败：{exc}')


if __name__ == '__main__':
    main()
